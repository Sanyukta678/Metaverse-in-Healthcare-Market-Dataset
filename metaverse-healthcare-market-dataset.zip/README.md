# Metaverse in Healthcare Market Dataset

This repository contains a compact dataset and supporting files extracted and summarized from the Next Move Strategy Consulting report: *Metaverse in Healthcare Market — Global Analysis & Forecast, 2025–2030* (report page: https://www.nextmsc.com/report/metaverse-in-healthcare-market-3630).

## About
This dataset aggregates key market insights, numerical indicators, segment details, and trends from the original report. It is suitable for academic research, business analysis, and data-driven projects.

## Files Included
- `README.md`
- `summary.txt`
- `metaverse_healthcare_summary.csv`
- `metadata.json`
- `LICENSE`

## Citation
Next Move Strategy Consulting — *Metaverse in Healthcare Market: Global Analysis & Forecast, 2025–2030*.  
https://www.nextmsc.com/report/metaverse-in-healthcare-market-3630
